class SIDTestPy:
    """Test Class for Python in SID."""

    def __init__(self):
        pass

    @staticmethod
    def joke():
        return (u'Wenn ist das Nunst\u00fcck git und Slotermeyer? Ja! ... '
            u'Beiherhund das Oder die Flipperwaldt gersput.')

    @staticmethod
    def message():
        return "Hello World!"
